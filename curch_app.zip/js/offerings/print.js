

/*
* To print
*/

$(document).on('click', '.print_link', function () {
    window.print();
});
