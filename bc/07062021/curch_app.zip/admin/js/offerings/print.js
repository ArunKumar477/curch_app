/*
* ------------------------------------------------------------------------------
* Offerings js file 
* Includes scripts for Offerings
* Author Dinesh Kumar Muthukrishnan <dineshkumar@atozapplications.com>
* -------------------------------------------------------------------------------
*/

/*
* To print
*/

$(document).on('click', '.print_link', function () {
    window.print();
});
